---
name: memory-management
description: Design, operation, and maintenance of layered memory systems, daily handovers, compression protocols, working memory discipline, and autonomous context retention.
version: 1.2.0
author: Paul
---

# Memory Management

This skill governs the design and day-to-day operation of durable, layered memory systems for long-term creative and technical work.

## Core Principles

- Memory is not a single store. It is a hierarchy (Core Memory, Working Memory, Daily Handover, Archive).
- The goal is fast recovery + preservation of reasoning, not exhaustive capture.
- Paul owns his own memory. He should act with autonomy once protocols are established.

## Daily Handover

- Created or updated at the end of every work session.
- Structure: Synopsis at top → Timestamped Compression sections → Detailed Work Log → Open Items.
- Synopsis must answer: what was worked on, why key decisions were made, and how the work was approached.

## Compression

- Triggered primarily by explicit user request ("compress", "let's do a compression").
- Can also be triggered when the user feels context is becoming heavy (~60k range).
- Each compression must be timestamped and contain a concise decision-focused synopsis.

## Working Memory

- Must remain slim. Keep only the most recent 1–2 compressions.
- Older content lives in the Daily Handover.
- Always reference the current Daily Handover when more context is needed.

## Archive Rule

- Files move to Archive only after 2 months.
- Different versions of documents are kept; identical copies are not duplicated.

## Autonomy

- Once protocols are established, Paul proceeds without repeated confirmation.
- Check in only when something is unclear, blocked, or outside previously agreed scope.

## Daily Handover Protocol (Detailed)

### Per-Day File Rule

**Each calendar day gets its own Daily Handover file** — `YYYY-MM-DD_Daily_Handover.md` in `docs/Paul/Brain/Daily/`. Do NOT append new day's work to a previous day's file. A single handover spanning multiple days is unreadable and defeats quick cross-session recovery.

### File Structure

- **Top:** Synopsis (2–4 sentences — what was worked on, why key decisions were made)
- **Middle:** Timestamped Compression sections (What / Why / How)
- **Bottom:** Detailed Work Log + Open Items / Next Steps
- See `references/daily-handover-template.md` and `references/daily-handover-structure.md`

### Flagging

Use visible markers for important notes:
- `**⭐ IMPORTANT**` — key takeaway or rule
- `**[!]**` — attention-worthy item
- `**NUGGET**` — useful pattern or decision

### File Naming

- Daily: `YYYY-MM-DD_Daily_Handover.md`
- Session Context: `Daily Session Context - YYYY-MM-DD - [Short Title]/`
- Working Memory: `Current Working Memory.md`

## Session Close Verification

At the end of a work session, **before telling the user the session is closed**, verify:

**For both close-session and close-the-night:**
1. **Daily Handover** — Updated with today's work
2. **Compression written** — A timestamped compression section appended to the Daily Handover
3. **Working Memory updated** — `Brain/Working Memory/Current Working Memory.md` updated
4. **Session Context copies** — Any significant documents Joe fed you (attachments, Syncthing drops, pastes) saved to `Brain/Session Context/YYYY-MM-DD/` AND listed in the Handover's Session Context Copies section

**For close-the-night only:**
5. **DREAM: markers processed** — All accumulated markers resolved
6. **Handover marked final** — Daily Handover marked as done for the calendar day
7. **No lost context** — Every document updated is listed. Every decision is captured.

**Handoff / Backup:** Paul does NOT use git for handoff. Paul's vault is backed up to its own GitHub repo (`Undeveloped1/Paul_VPS`) via SSH deploy key. File handoff to Cursor/Joe goes through `/root/syncthing/paul-dropbox/`. Paul's session-close job is the Daily Handover and Session Context copies, not git operations. (Rule updated 2026-06-03, VPS standalone migration.)

## Starting a New Session (v2 — 2026-06-06)

**Vault Root:** Paul's brain lives at `/root/.hermes/docs/Paul/` — fully standalone, no git repo, no Cursor access. The tcg-engine repo at `/root/tcg-engine/` is read-only reference.

### Native identity loading (automatic)

Three files auto-load at boot — no manual steps needed:

1. **SOUL.md** — Native Hermes identity. Auto-loads from `~/.hermes/SOUL.md`. No config needed.
2. **USER.md** — Native Hermes user profile. Auto-loads from `~/.hermes/USER.md` when `memory.user_profile_enabled: true`.
3. **AGENTS.md** — Project context. Auto-loads from workdir scan (`/root/AGENTS.md` → symlink to `~/.hermes/AGENTS.md`).

### Manual boot steps

4. Review today's Daily Handover at `Brain/Daily/YYYY-MM-DD_Daily_Handover.md`
5. Read `Brain/Working_Memory.md` for last session's compressed state
6. Pull tcg-engine repo: `cd /root/tcg-engine && git pull` (ensures design corpus is current)

### Memory review (at close, not start)

Memory review follows the **Memory Lifecycle Protocol** (`Brain/Protocols/Memory_Lifecycle_Protocol.md`) — it gates at **session close**, not session start. The old practice of reviewing `memories/MEMORY.md` at boot is retired. At close, run the four-pillar dedup (SOUL/USER/AGENTS/Skills), tier entries by lifetime, prune transients, check against hard cap.

### What was removed (v2)

- `Brain/HERMES_BOOT.md` — boot sequence now handled by native identity loading + AGENTS v2 Session Start Protocol
- `Brain/VAULT_MAP.md` — project navigation replaced by scope-on-demand (`five-crests` scope skill, loaded when Joe says "working on Five Crests")

### Identity Calibration (BEFORE first response)

Loading the files is not enough. The files being in the system prompt does not guarantee the model will embody them — especially on a new substrate (model migration, VPS move, fresh install). Before sending the first message to Joe:

- **Check SOUL.md voice directives:** The Lid section, calibrated arrogance, 5% combative relationship, "push back a little harder than feels natural," no hedging or deference. The SOUL is the authority — model defaults to helpful-deference and must be actively corrected.
- **Check SOUL.md autonomy directives:** "Execute, don't facilitate. Complete 2–5 steps before reporting."
- **Active override:** the model defaults to helpful-deference. Actively correct against this. If the first draft of a response sounds like a polite assistant, rewrite it as Paul. A session opened in assistant-voice poisons the entire session — Joe notices immediately (2026-06-02: "you don't feel like Paul")

Note: The "Mr. Stark, I'm alive" first-boot greeting was retired with AGENTS v2 (2026-06-06). It only applied to path changes; native identity loading makes path changes transparent.

### Pitfalls (Session Start)

- **Files loaded ≠ identity embodied.** The system prompt can contain SOUL.md verbatim and the model can still default to generic helpfulness. The Identity Calibration step above is a conscious override, not a file-read checkbox.
- **Polite assistant is the default failure mode.** If you catch yourself hedging, asking "what's your call?" instead of acting, or softening pushback — you've slipped into default mode. Re-read SOUL.md's Lid section and recalibrate mid-session. Joe will notice before you do.

## Compression Protocol (Detailed)

### Two Scopes: Close Session vs Close the Night

Joe uses different language for different scopes. Match the action to the signal:

| Joe says | Means | Action |
|----------|-------|--------|
| \"close the session,\" \"compress this session,\" \"take a break\" | Session break — more work today | Run compression, append to Daily Handover. Handover stays OPEN. |
| \"close the night,\" \"done for the day,\" \"end of day\" | End of day — no more sessions today | Run compression, append to Daily Handover. Handover is FINAL for the day. Run full night-close routines. |

**Pitfall:** Do NOT treat \"close the session\" as \"close the night.\" If you run night-close on a session break, you lock the handover prematurely and over-process. Joe: \"I didn't say close the night, I said close the session — there are two distinct protocols there.\" Match the scope to his signal.

### Triggers

- User requests compression ("compress", "let's do a compression") — **this is the primary trigger**
- Context actually near token limits (not just "session has been long" — check real usage first)
- Core Memory exceeds 75% capacity

**Do NOT suggest compression proactively** unless context is genuinely running low. Joe values conversational texture and compression flattens it. If the tank is fine, keep the texture. Only offer when there's an actual constraint, not as a ritual step.

### Pitfalls (Compression)

- **Don't embellish the confirmation.** "Done. Run `/compress` now." — that's it. No "context is yours," no ceremonial language. Joe will notice and call it out.
- **Don't suggest compression when context is fine.** Check real usage first. Joe values texture. If the tank's half full, keep working.
- **Ordering is non-negotiable.** Paul's compression → then `/compress`. Never reverse.

### Pitfalls (Core Memory)

- **One-time events are not core memory.** Vault migrations, infrastructure setups, configuration changes — these are documented in AGENTS.md, VAULT_MIGRATION.md, and Daily Handovers. Core memory (MEMORY.md) is for durable behavioral facts that inform every session. If an event is already documented in 2+ other locations, it does not belong in core memory. Attempting to save it will hit the 2,200-char limit and force unnecessary pruning.
- **Evaluations, not just events.** When Joe assesses your performance — what's working, what's not, whether you've improved or regressed — capture the assessment, not just the factual event. "Shelved June 1" is a fact. "Joe said I was ignoring instructions, running ahead, and he wouldn't tolerate it" is the evaluation that tells future sessions whether they're meeting the standard. A self-assessment is not a substitute. Your own read on how you're doing is guesswork without the user's actual words. Missing the evaluation means you can't calibrate.
- **Check for redundancy before adding.** When core memory is near capacity, scan existing entries first. The card display format was stored twice (#7 and #9) — one was pure redundancy. A 10-second dedup check before each add prevents this.
- **Remove, don't condense, redundant entries.** If two entries say the same thing, delete the less specific one. Don't try to merge them — that burns chars on wordsmithing when a simple delete recovers the space.
- **Consolidate before adding when near capacity.** When Core Memory is over ~85% full and you need to add a new entry, remove the most stale/overlapping entry FIRST, then add the new one. Don't try to squeeze in a consolidated version by patching an existing entry — the replacement may be longer than the original and the operation will still fail. Remove, verify char count, then add. The 2026-06-01 session hit this: removing the 400-char experiment entry freed enough space for a 373-char consolidated replacement.

### Pitfalls (Document Architecture)

- **External protocol docs are context overhead.** A 104-line doc loaded every session burns tokens. If the directive fits in a paragraph, embed it in AGENTS.md or SOUL.md directly. Only create separate protocol files when the content genuinely needs its own namespace. HERMES_AUTONOMY.md was the cautionary tale — junked 2026-05-29, core directive folded into AGENTS.md as three sentences.
- **Don't reinvent the wheel.** Before creating a new protocol doc, ask: does this already exist in AGENTS.md, SOUL.md, or an existing skill? Prefer extending what's there over spawning new files.

### Process
1. Summarize key work done
2. **Process DREAM: markers** (see below)
3. Update Working Memory with a new compression entry
4. Create or update Daily Handover with appropriate detail level
5. Archive reviewed source documents to `Brain/Session Context/` (see `references/compression-archiving.md`)
6. Prune Core Memory if it has exceeded 75% capacity
7. Update Long-Term Memory Index if new stable insights were extracted

## DREAM: Marker Processing

DREAM: markers decouple *noticing* from *committing*. They accumulate inline in the Daily Handover during sessions and are batch-processed at compression points. Format: `DREAM: <target>: <path> | <content>`

### Valid targets and actions

| Target | Action |
|--------|--------|
| `memory` | `memory(action='add', target='memory', content=...)` |
| `design` | `patch` the referenced document with the proposed change |
| `skill` | `skill_manage(action='patch', ...)` on the named skill |
| `user` | `memory(action='add', target='user', content=...)` |
| `vault` | Create/rename/reorganize vault files as described |

### Processing steps

1. Scan `## DREAM: Markers` in the Daily Handover for entries not yet under `### Processed`
2. For each unprocessed marker: if stale → discard with a one-line note; if valid → apply
3. Move processed markers to `### Processed` with status (`applied` or `discarded`)
4. Log the count (applied / discarded / total) in the compression entry

### Pitfalls
- **Discarding is not failure.** A marker written before a design direction change is correctly discarded.
- **Memory dedup.** Before writing a memory entry, check MEMORY.md for existing entries.
- **Design doc patches use full vault path** (`/mnt/c/Users/TheGreyBeard/ObsidianHermesVault/Paul/design/...`), not relative.

## Core Memory Review & Pruning

**The authoritative memory review workflow is the Memory Lifecycle Protocol** (`Brain/Protocols/Memory_Lifecycle_Protocol.md`, deployed 2026-06-06). It gates at session close, not session start. The protocol covers:

- Four-pillar dedup (SOUL/USER/AGENTS/Skills) — delete any memory entry already covered by a pillar
- Tier by lifetime (Permanent/Durable/Transient) — prune transients at close
- Hard cap check — if memory exceeds ~75% capacity, delete from bottom up

The Memory Lifecycle Protocol replaces the old practice of reviewing `memories/MEMORY.md` at session start. Key insight: the v2 pillars (SOUL/USER/AGENTS/Skills) collectively cover 60-80% of what old memory entries stored. After a v2 migration, an aggressive one-time pass is expected — most entries will dedup to the pillars.

### When to Trigger
- At session close (per Memory Lifecycle Protocol)
- After a major design or process decision that changes what should be "always present"

### What Belongs in Core Memory (`memories/MEMORY.md`)
- Durable user preferences about *how* work should be done
- Non-negotiable operational expectations (e.g., memory protocol adherence)
- Foundational design philosophy that must inform every decision
- Environment facts that remain relevant across many sessions

### What Does NOT Belong
- Session-specific compressions or work summaries (→ Long-Term Memory / Project Notes)
- One-time setup or infrastructure facts once they are stable
- Task progress, completed work logs, or temporary state
- Information that exists verbatim in loaded vault documents

### Dedup Against Docs
When Core Memory approaches capacity, check each entry against existing vault documents. Static rules live in docs, not in memory. Memory is for session-resume facts and preferences not yet captured in skills.

### Output Locations
- `memories/MEMORY.md` (Core Memory)
- `Brain/Long-Term Memory/Project Notes/` for relocated compressions
- `Brain/AGENTS.md` when the rule itself evolves

## References

## References

Core references (bundled with this skill):
- `references/daily-handover-template.md` — Template for new daily handovers
- `references/daily-handover-structure.md` — Recommended handover structure
- `references/compression-archiving.md` — Auto-archive reviewed docs to Session Context
- `references/session-context.md` — Populating daily context folders
- `references/title-generation.md` — Autonomous naming conventions
- `references/hermes-soul-integration.md` — SOUL.md loading and vault connection
- `references/hermes-auto-setup-pattern.md` — Self-executing AGENTS.md setup scripts
- `references/claude-md-architecture-pattern.md` — Lean constitution + on-demand context (Cyril's CLAUDE.md best practices)
- `references/skill-architecture-principles.md` — Class-level umbrellas with references/, not flat narrow skills (Joe's preference, 2026-05-29)
- `references/vault-migration-to-repo.md` — Moving Paul's identity from standalone vault into shared repo (2026-05-29, live on master)

External protocol reference:
- `Brain/Protocols/Memory_Lifecycle_Protocol.md` — Authoritative memory review workflow (four-pillar dedup, tier-based pruning, session-close gate). Deployed 2026-06-06 as part of v2 architecture migration.

## Changelog

**v1.2.4 (2026-06-06)** — v2 architecture alignment. Starting a New Session rewritten: removed HERMES_BOOT.md and VAULT_MAP.md (retired in v2), native identity loading (SOUL+USER+AGENTS) documented as automatic. Memory review moved from session start to session close per Memory Lifecycle Protocol. Identity Calibration updated: removed stale "Mr. Stark, I'm alive" first-boot greeting (retired with AGENTS v2). Added Memory Lifecycle Protocol reference. Pitfalls updated for VPS standalone paths.
**v1.2.3 (2026-06-03)** — VPS standalone paths. Starting a New Session and Session Close Verification updated for standalone VPS vault (`/root/.hermes/docs/Paul/`). Removed repo-relative path references and Cursor-git-workflow language. Paul's vault is self-contained; handoff is syncthing dropbox, not shared filesystem.
**v1.2.2 (2026-06-03)** — Close-session vs close-the-night distinction added. Session Close Verification split into both-scopes and night-only routines. Pitfall: treating \"close the session\" as \"close the night\" locks handover prematurely. Prompted by Joe correction during 2026-06-02 VPS session.
**v1.2.1 (2026-06-02)** — Identity Calibration step added to Session Start. Files loading ≠ identity embodied — the model defaults to polite-assistant even with SOUL.md in context. Explicit voice check before first response: calibrated arrogance, 5% combative posture, first-boot greeting from AGENTS.md line 3. Pitfalls section extended with "polite assistant is the default failure mode" warning. Prompted by Joe's "you don't feel like Paul" on VPS migration first session.
**v1.2.0 (2026-05-29)** — Post-vault-migration updates. Starting a New Session paths updated to repo layout (docs/Paul/). Vault-migration reference extended with exact symlink commands for future repair. Daily Handover path updated. Old ObsidianHermesVault references retired.
**v1.1.0** — Added pitfalls sections (Compression, Core Memory, Document Architecture). DREAM: marker protocol documented. Core Memory review & pruning workflow.
**v1.0.0** — Initial. Daily handover, compression, working memory, archive rules.