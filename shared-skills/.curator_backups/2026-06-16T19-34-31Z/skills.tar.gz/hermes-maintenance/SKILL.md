---
name: hermes-maintenance
description: Update, audit, and maintain the Hermes Agent installation — running updates, handling user-modified bundled skills, auditing skill library for dead weight.
tags: [hermes, maintenance, update, skills, audit]
---

# Hermes Maintenance

## When to Use

- User runs `hermes update` or asks to update Hermes
- User asks about user-modified skills blocking updates
- User wants to audit the skill library for bloat or dead weight
- After an update completes and reports "user-modified (kept)" skills
- User wants to migrate Hermes to a VPS or new machine — see `references/vps-migration.md` for full plan
- User is deploying to Hostinger VPS (or troubleshooting a Hostinger template) — see `references/hostinger-vps.md` for template-specific details
- **Paul wakes up after a migration with amnesia/disorientation** — see `references/post-migration-orientation.md` for the SPARK.md protocol and orientation checklist
- **Pre-migration: create SPARK.md** — before migrating Paul's identity files, the source Paul should write a SPARK.md bridge document (shorthand, inside jokes, current state, tone) to `docs/Paul/Brain/SPARK.md`. The destination Paul reads this on first boot to skip the disorientation period. See `references/post-migration-orientation.md` for the format.
- **VPS file sync between Joe and Paul** — Syncthing is set up for peer-to-peer sync. See `references/syncthing-setup.md` for device ID, service management, and verification.
- **Gateway platform issues** — Telegram "Unauthorized user," stuck pairing codes, WhatsApp pairing failures, gateway restart stalls. See `references/gateway-troubleshooting.md`.
- **Dashboard SSH tunnel access** — setting up `paul-dash` SSH config alias, WSL heredoc pitfalls, port 9119, desktop app remote session token. See `references/dashboard-ssh-tunnel.md`.
- **AGENTS.md not auto-loading at session start** — Hermes loads from working directory (`/root`), not `~/.hermes/`. Symlink fix, verification, update-survival. See `references/agents-md-auto-load.md`.
- **Paul vault path structure (VPS standalone)** — canonical paths, golden rules, path duality, common mistakes. See `references/paul-vault-structure.md`.
- **GitHub backup repo setup** — `gh` CLI install, PAT authentication, vault backup push, token security. See `references/github-backup-setup.md`.

## Update Workflow

```bash
hermes update
```

The updater syncs bundled skills from the repo into `~/.hermes/skills/`. It respects local modifications — if you've edited a bundled skill, it keeps your version and reports "~N user-modified (kept)."

**Post-update checks:**

1. **Dashboard WILL be killed — and systemd will NOT auto-restart it.** The updater sends SIGTERM to stop the dashboard (backend no longer matches updated frontend). The standard systemd service uses `Restart=on-failure` which only triggers on non-zero exit codes — clean SIGTERM produces exit 0, so the dashboard stays dead. **Always restart manually after `hermes update`:**

   ```bash
   systemctl --user restart hermes-dashboard   # if running as systemd service
   # OR
   hermes dashboard --host 127.0.0.1 --port 9119 --no-open --skip-build &   # manual fallback
   ```
   Verify: `ss -tlnp | grep 9119` should show LISTEN.

   **Permanent fix — change systemd to `Restart=always`:** The root cause is `Restart=on-failure` ignoring clean exits (SIGTERM = exit 0). One-line fix so this never happens again:

   ```bash
   sed -i 's/Restart=on-failure/Restart=always/' ~/.config/systemd/user/hermes-dashboard.service
   systemctl --user daemon-reload
   systemctl --user show hermes-dashboard -p Restart   # should output: Restart=always
   ```

   After this, the dashboard auto-recovers within 5 seconds of any update — no manual restart needed. The gateway already uses `Restart=always` by default; only the dashboard unit ships with `on-failure`.

   **Symptom if skipped:** The user sees a "channel 3 error" in the desktop app or web dashboard. This is the frontend trying to connect to a backend that doesn't exist. The "channel" is a WebSocket/SSE event channel — when the backend is dead, the frontend's channel subscription fails. The error text varies ("channel 3 error" is common) but the root cause is always: dashboard process not running after update.

   **Client-side fix:** Even after restarting the backend, the user's browser or desktop app may have cached the old frontend JS bundles (which reference stale channel numbers). Hard refresh: Ctrl+Shift+R (Cmd+Shift+R on Mac). For the Electron desktop app, if hard refresh doesn't work, open DevTools (Ctrl+Shift+I), check "Disable cache" in the Network tab, then reload.

2. **Gateway restarts automatically** — verify with `hermes gateway status`. The updater drains and restarts the gateway; messaging platforms will briefly disconnect and reconnect.

## Auto-Updating Hermes via Cron

To keep Hermes updated without manual intervention, schedule a periodic `hermes update` via cron:

```bash
# Example: weekly update every Sunday at 3 AM
hermes cron create auto-update-hermes "30 3 * * 0" "Run hermes update to pull latest Hermes Agent version and sync bundled skills. After the update completes, verify the dashboard is still running. If it was killed by the updater, restart it: hermes dashboard --host 127.0.0.1 --port 9119 --no-open --skip-build &"
```

The updater will kill the dashboard (SIGTERM, exit 0). If you've applied the permanent fix above (`Restart=always`), systemd auto-restarts it — no cron action needed beyond verifying it came back. If still on `Restart=on-failure`, the cron prompt MUST include a manual `systemctl --user restart hermes-dashboard`. The gateway restarts automatically either way.

## Gateway Troubleshooting

Common gateway platform issues — Telegram auth, pairing codes, WhatsApp pairing, restart stalls. See `references/gateway-troubleshooting.md` for quick fixes.

## Post-Update: Check User-Modified Skills

After every update that reports `user-modified (kept)`, investigate what was kept and why.

**Reliable method — hash comparison** (catches extra files, not just text diffs):

```python
import hashlib
from pathlib import Path

BUNDLED = Path.home() / ".hermes/hermes-agent/skills"
LOCAL = Path.home() / ".hermes/skills"

def dir_hash(base, rel):
    p = base / rel
    if not p.exists():
        return None
    h = hashlib.md5()
    for f in sorted(p.rglob("*")):
        if f.is_file():
            h.update(str(f.relative_to(p)).encode())
            h.update(f.read_bytes())
    return h.hexdigest()

# Find skills in manifest that exist locally but differ from bundled
manifest = {}
mp = LOCAL / ".bundled_manifest"
if mp.exists():
    for line in mp.read_text().splitlines():
        if ":" in line:
            n, _, h = line.strip().partition(":")
            manifest[n.strip()] = h.strip()

for name in sorted(manifest):
    # Resolve manifest key to directory path — check both flat and nested
    for root, dirs, _ in LOCAL.walk():
        for d in dirs:
            sp = Path(root) / d
            if (sp / "SKILL.md").exists():
                # Read frontmatter name
                fm = sp / "SKILL.md"
                first = fm.read_text().split("---")[1] if fm.read_text().startswith("---") else ""
                if f"name: {name}" in first:
                    local_h = dir_hash(LOCAL, sp.relative_to(LOCAL))
                    bundled_h = dir_hash(BUNDLED, sp.relative_to(LOCAL))
                    if local_h and bundled_h and local_h != bundled_h:
                        print(f"MISMATCH: {sp.relative_to(LOCAL)}")
                        print(f"  local:   {local_h}")
                        print(f"  bundled: {bundled_h}")
```

**Do NOT use `diff -rq` for this.** It reliably fails because bundled skills use nested directories (`research/polymarket`, `apple/notes`) while local skills may be flat or differently nested. `diff -rq` returned zero output in a session where `polymarket` was confirmed user-modified with extra files. The Python hash approach above is the only reliable method.

**Decision rule:** If the customization is already captured elsewhere (identity files, AGENTS.md, memory system, or should be its own standalone skill), strip the customization and let upstream flow through. If the customization is genuinely unique to your workflow and not redundant, keep it — but prefer extraction to a separate skill over permanent forking of a bundled skill.

## Resetting a User-Modified Skill to Stock

When a bundled skill has been locally modified and you want to discard the changes so upstream updates flow through clean:

```bash
rm -rf ~/.hermes/skills/<path/to/skill>
cp -r ~/.hermes/hermes-agent/skills/<path/to/skill> ~/.hermes/skills/<path/to/skill>
```

Then update the manifest hash to match the fresh copy so the updater no longer treats it as user-modified. Compute the new hash with `dir_hash()` (above) and replace the manifest entry. On next `hermes update`, the skill syncs clean.

## Pitfall: Customizing Bundled Skills With Redundant Content

**Don't** modify a bundled skill to add content that's already documented in:
- SOUL.md or USER.md (identity/personality)
- AGENTS.md (working protocols)
- MEMORY.md (core memory)
- Another dedicated skill

**Why:** Each modification blocks that skill from receiving upstream updates. Over months, the skill drifts from the maintained version and you miss improvements.

**Example:** The obsidian skill had a section about Paul's identity files and symlink setup. That content was already fully captured in SOUL.md, AGENTS.md, and the memory system. The customization blocked 10+ days of potential upstream improvements for zero functional gain.

**If the content is genuinely unique and should persist:** Create a separate skill for it rather than modifying the bundled one. Example: polymarket paper trader content should be its own `polymarket-paper-trader` skill, not bolted onto the bundled `polymarket` skill.

## System Prompt & Model Diagnostics

See `references/system-prompt-inspection.md` for:
- Tracing what Hermes sends to the model (SOUL vs. DEFAULT_AGENT_IDENTITY, guidance blocks, tier structure)
- OpenRouter model discovery (API query, filtering, alignment assessment)
- Model selection guide: which models have looser RLHF and higher autonomy ceiling

## Auditing for Dead Skills

When the user asks about unused or bloated skills, audit the full library.

**Before auditing, check which tools are actually functional.** A skill can be present, loaded, and appear valid while its underlying tool is broken or unauthenticated:

```bash
# Example: xurl was installed (which xurl → /home/.../bin/xurl) and its skill loaded,
# but `xurl whoami` returned 401 — never authenticated. Skill was dead weight.
xurl whoami 2>&1
```

This catches the case where a tool is installed but never configured, making its skill dead weight regardless of how relevant the domain is.

```bash
find ~/.hermes/skills -name SKILL.md | sort | while read f; do
  name=$(echo "$f" | sed 's|.*/skills/||; s|/SKILL.md||')
  desc=$(grep -m1 '^description:' "$f" | sed 's/description: *//')
  echo "$name|$desc"
done
```

Group into:
- **Core** — loaded nearly every session (e.g., bruiser-card-design-pipeline, creative-collaboration)
- **Situational** — loaded occasionally for specific tasks (e.g., github-*, software-development/*)
- **Dead weight** — never loaded, unrelated to the user's actual work (e.g., apple/* on WSL, mlops/* for a game dev, baoyu-* Chinese content tools)

Present the triage and let the user decide. Don't delete without confirmation.

## Permanently Removing Bundled Skills

Simply `rm -rf`-ing a bundled skill directory is not enough — the next `hermes update` will see the skill as "not in manifest, not on disk" and re-copy it from the bundled repo. The skill sync logic (`tools/skills_sync.py`) uses a manifest at `~/.hermes/skills/.bundled_manifest` to track which skills have been synced:

| Manifest state | Disk state | Updater behavior |
|---------------|-----------|-----------------|
| Not in manifest, not on disk | Missing | **Copies from bundled** (treats as new) |
| In manifest, on disk, hash matches origin | Present | Updates if bundled changed |
| In manifest, on disk, hash differs | Present | **Skips** (user-modified, kept) |
| In manifest, not on disk | Deleted | **Skips** (user-deleted, respected) |

**The pattern:** to permanently remove a bundled skill so it never returns on update:

1. **Read the manifest** at `~/.hermes/skills/.bundled_manifest` (format: `skill_name:origin_hash` per line)
2. **For each skill NOT in the manifest:** add it first. Read the skill's frontmatter `name:` field from its bundled `SKILL.md` to get the correct manifest key. Compute the origin hash from the bundled directory (MD5 of all file contents, same algorithm `_dir_hash()` uses).
3. **Delete the skill directories** from `~/.hermes/skills/`
4. **Write the updated manifest** back

On next `hermes update`, every deleted skill is "in manifest, not on disk" → updater skips it.

**Python reference** (for bulk deletion — adapt the `dead` list):

```python
import hashlib, shutil
from pathlib import Path

MANIFEST = Path.home() / ".hermes/skills/.bundled_manifest"
SKILLS_DIR = Path.home() / ".hermes/skills"
BUNDLED_DIR = Path.home() / ".hermes/hermes-agent/skills"

# Read manifest
manifest = {}
if MANIFEST.exists():
    for line in MANIFEST.read_text().splitlines():
        if ":" in line:
            name, _, h = line.strip().partition(":")
            manifest[name.strip()] = h.strip()

# For each dead skill, ensure manifest entry exists, then delete
for rel_path in dead_skill_paths:
    skill_path = SKILLS_DIR / rel_path
    name = read_frontmatter_name(skill_path / "SKILL.md")  # implement this
    
    if name not in manifest:
        bundled = BUNDLED_DIR / rel_path
        h = hashlib.md5()
        if bundled.exists():
            for fp in sorted(bundled.rglob("*")):
                if fp.is_file():
                    h.update(str(fp.relative_to(bundled)).encode())
                    h.update(fp.read_bytes())
        manifest[name] = h.hexdigest()
    
    shutil.rmtree(skill_path)

# Write manifest back
MANIFEST.write_text(
    "\n".join(f"{n}:{h}" for n, h in sorted(manifest.items())) + "\n"
)
```

**To undo** (re-add a previously deleted skill): `hermes skills reset <name>` clears the manifest entry so the next sync treats it as new and re-copies from bundled.
