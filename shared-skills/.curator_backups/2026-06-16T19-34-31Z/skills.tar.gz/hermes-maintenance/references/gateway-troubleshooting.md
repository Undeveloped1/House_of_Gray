# Gateway Troubleshooting

Quick-reference for common Hermes gateway platform issues.

## Telegram: "Unauthorized user" on first contact

**Symptom:** `WARNING gateway.run: Unauthorized user: <ID> (Name) on telegram` in gateway logs.

**Root cause:** `TELEGRAM_ALLOWED_USERS` in `.env` is either unset or set to the bot's own username (e.g., `@DrPaulStoneBot`) instead of the human user's Telegram ID.

**Fix:**
```bash
# 1. Get user ID from the log line (e.g., 7239715879)
# 2. Set the correct allowed user
sed -i 's/TELEGRAM_ALLOWED_USERS=.*/TELEGRAM_ALLOWED_USERS=<USER_ID>/' ~/.hermes/.env
# 3. Clear any stale pairing codes
hermes pairing clear-pending
# 4. Restart gateway
hermes gateway restart
```

User then needs to message the bot again. The allowlist bypasses the pairing flow entirely.

## Telegram: Stale pairing code won't approve

**Symptom:** `hermes pairing list` shows a pending code, but `hermes pairing approve telegram <CODE>` fails with "not found or expired" despite the code still appearing in the list.

**Fix:** Clear and let the user re-trigger:
```bash
hermes pairing clear-pending
```
Then have the user message the bot again. If `TELEGRAM_ALLOWED_USERS` is correctly set, the new message auto-approves.

## Protected file editing

`.env` and other credential files are protected from the `patch` tool. Use `sed` via terminal instead:
```bash
sed -i 's/OLD_PATTERN/NEW_VALUE/' ~/.hermes/.env
```

## Telegram: Bot not responding in a new group

**Symptom:** User creates a group, adds the bot, sends messages — no response. Group doesn't appear in `send_message(action='list')`. Bot works fine in DMs.

**Root cause:** Telegram bots have **privacy mode ON by default**. In privacy mode, the bot only sees:
- Commands (messages starting with `/`)
- Messages where the bot is `@mentioned`
- Replies to the bot's own messages
- Service messages (joins, leaves)

If the user sends a plain message without @mentioning the bot, the gateway never receives it — the group isn't even registered.

**Diagnostic (from the agent side):**

*Step 1 — Check targets:*
Use `send_message(action='list')` to see all registered targets. If the group isn't there, the gateway hasn't registered it yet.

*Step 2 — Verify messages are reaching the gateway:*
```bash
grep -i "telegram\|group\|chat_member\|my_chat_member" /root/.hermes/logs/gateway.log | tail -20
```
If the DM chat ID (7239715879) is the only one appearing, the group messages are not reaching the gateway at all. Do NOT waste time on gateway config — the problem is on the Telegram side (privacy mode). Note: `journalctl` will NOT show gateway logs; they live at `/root/.hermes/logs/gateway.log`.

**Fix (two options):**

*Option A — One-time mention (no config change):*
User sends a message in the group containing `@BotUsername`. This triggers visibility. An explicit @mention may be required for future messages too unless privacy mode is disabled.

*Option B — Disable privacy mode permanently:*
User chats with `@BotFather` → `/mybots` → pick the bot → **Bot Settings** → **Group Privacy** → **Turn OFF**. Then remove and re-add the bot to the group. All messages will now be visible without @mentions.

## Gateway restart stalls

If `hermes gateway restart` hangs, check:
```bash
systemctl --user status hermes-gateway
journalctl --user -u hermes-gateway --no-pager --since "2 min ago"
```
Common causes: WhatsApp bridge not paired (pre-2026-06-03), credential exhaustion, or port conflict.
