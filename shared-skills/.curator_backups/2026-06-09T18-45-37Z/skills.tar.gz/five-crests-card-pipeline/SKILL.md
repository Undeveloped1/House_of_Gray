---
name: five-crests-card-pipeline
description: "Master skill for the Five Crests card design pipeline. Load when Joe says 'build cards for [faction]' or 'run the pipeline.' Orchestrates the full stack from identity gate through compound tracking."
category: creative
---

# Five Crests Card Design Pipeline — Master Skill

## What This Is

The complete end-to-end process for producing a 55-card Five Crests faction set from locked lore through autonomous sub-agent production. This skill ties together the orchestrator, faction-identity-gate, pathway-design, faction-set-review, density_calc.py, and pre_review_audit.py.

**Proven on:** Trigger v7 (A-, autonomous), Faceless v2 (A-, overnight autonomous)
**Compound trajectory:** Each faction starts higher. Duster projected 85%+ first attempt.

## When to Use

- Joe says "build the [faction] card set"
- Joe says "run the pipeline for [faction]"
- Starting a new faction from locked lore
- Re-running a faction with improved process

## The Process (7 Phases)

### Phase 0: Identity Gate

**Goal:** Confirm the faction is worth building before touching mechanics.

**Steps:**
1. Load `faction-identity-gate` skill
2. Read the faction's lore docs (Identity Bible, Design Bible, Inner Circle, Territory, Playstyle)
3. Score all 10 dimensions (1-5 each)
4. Run the 4 synthesis locks (Mechanic-Villium, Mechanic-Fantasy, Blind Spots-World, Crews-Heroes)
5. Check surprise flag

**Gate:** 40+ total, 0 dimensions below 3, 0 drift locks. Below gate = fix identity. Do not proceed.

**Deliverable:** Scored identity gate report with verdict, ranked gaps, drift-risk flags.

### Phase 1: Spec Lock

**Goal:** Lock EVERYTHING a sub-agent needs before spawning any workers.

**Steps:**
1. Build Function Registry (12-18 functions derived from lore, NOT retrofitted from existing cards)
2. Build Synergy Web (edges between functions with types: Enables, Creates-Spends, Curve Chain, Protects)
3. Lock Build Facts (card count, curve, rarity distribution, crew percentages, legendary slots)
4. Lock Blind Spots (what the faction CANNOT do — 2-3 clear, meaningful constraints)
5. Lock Crew CAN/CANNOT profiles (which crew gets which mechanics)
6. Run `density_calc.py` — confirm draw probabilities for signature mechanics

**Gate:** All documents cross-referenced. No contradictions. Crew profiles reconciled against function registry.

**Deliverable:** Locked function registry, synergy web, build facts, crew profiles.

### Phase 2: Pathway Design

**Goal:** Convert identity into density targets, turn maps, and slot boundaries.

**Steps:**
1. Load `pathway-design` skill
2. Build crew identity profiles (one paragraph each: who they are, what they do, emotional core)
3. Build archetype turn maps (T1-T6 sequence with cross-pathway support)
4. Build slot table:
   - 29 minion rows: each with crew, V-band, rarity, mechanic band, pathway
   - 21 spell slots
   - 5 weapon slots
5. Calculate density targets from slot table

**Gate:** Slot table totals = card count. Crew percentages match targets. Turn maps feasible.

**Deliverable:** Complete Sub-Agent Spec document with all sections. This is the ONE document workers read.

**CRITICAL:** Spec docs must include ALL conversational nuance. Sub-agents only read the spec. If Joe said "Street doesn't get Paid because they're muscle, not accountants" — that reasoning must be in the spec. "NO SURNAMES on Professionals" — not "epithets only."

### Phase 3: Spec Validation

**Goal:** Catch spec errors before they cascade into 55 cards.

**Steps:**
1. Spawn a validator sub-agent with `delegate_task`
2. Validator checks:
   - Slot table math (crew budgets, rarity caps, V-band totals)
   - Crew bleed (Street with Paid, Help with Overkill, Management killing)
   - Mechanic density (Mark sources 6-10, Overkill 5-6, Barrage 1-2, Cloak 2-3, Hustle 2-3)
   - Pathway coverage (all three hero lanes represented)
   - Edge coverage (all synergy edges have cards)
   - Naming conventions (Professionals = epithets/role-names ONLY)

**Gate:** 0 Critical findings. Any Critical = fix the spec, re-validate. This is the HIGHEST-LEVERAGE step. Proven: caught 7 blocking errors on Trigger v7, 2 Critical crew contradictions on orchestrator run.

**Deliverable:** Validation report with severity-graded findings.

### Phase 4: Card Production

**Goal:** 55 cards produced in parallel by 3 sub-agents.

**Steps:**
1. Load `orchestrator` skill
2. Spawn 3 parallel workers with `delegate_task`:
   - Batch 1: 1V-2V (~20 cards)
   - Batch 2: 3V-4V (~22 cards)
   - Batch 3: 5V-6V (~13 cards)
3. Each worker receives: full Sub-Agent Spec + band-specific instructions + mandatory output format template
4. Verify format: grep for pipe table column counts. Mismatch = re-spawn worker with template constraint.
5. Assemble batches into combined set

**Gate:** Format verified. Card count correct. Workers wrote FILES, not summaries.

**Deliverable:** `assembled.md` — 55 cards in exact pipe table format.

### Phase 5: Automated Audit + Fixer

**Goal:** Mechanical gate before critic review.

**Steps:**
1. Run `pre_review_audit.py` on assembled set
2. If CLEAN → proceed to Phase 6
3. If FAIL → spawn fixer sub-agent:
   - Fixer fills specific gaps (missing removal, healing, thin edges, naming conflicts, rarity overflows)
   - Fixer does NOT redesign working cards
   - Fixer writes `fix-patch.md`
4. Apply fixes, re-run audit
5. If still FAIL after 2 fixer passes → escalate

**Gate:** pre_review_audit.py returns CLEAN (exit 0).

**Deliverable:** Audit-passed assembled set.

### Phase 6: Critic Review

**Goal:** Subjective quality review — what automation can't judge.

**Steps:**
1. Spawn critic sub-agent with `delegate_task`
2. Critic uses `faction-set-review` skill, Pass 2-3 (skip Pass 1 — pre_review_audit.py covered structural)
3. Critic returns: severity-graded findings (Critical/Major/Minor), letter grade, ship/iterate verdict
4. Apply Critical and Major fixes. Do NOT redesign cards that passed.

**Multi-perspective review (optional, recommended):**
For higher quality, spawn 3-5 reviewer sub-agents with different lenses:
- Tone reviewer: "Do these cards sound like [faction]?"
- Design reviewer: "Are the mechanics interesting and distinct?"
- Identity reviewer: "Do the cards feel like the faction they claim to be?"
- Flavor reviewer: "Do names, flavor text, and art direction cohere?"
- MTG Distinctiveness reviewer: "Is this novel or could it be an MTG set?"

Paul synthesizes findings; Joe only reviews the synthesis.

**Gate:** B+ or above ships. Below B iterates (fix + re-spin critic). Max 3 iterations.

**Deliverable:** Critic report + fixed set.

### Phase 7: Delta Tracking & Compound

**Goal:** Process improves itself. The next faction starts higher.

**Steps:**
1. Record delta entry: (resolved - new) / previous_total
2. Update COMPOUND_TRACKER.md
3. Spawn meta-critic sub-agent:
   - "What broke? What was missing from the spec? What would have prevented the failures?"
4. Apply meta-critic's approved patches to playbooks
5. Surface to Joe with standard report format

**Gate:** Improvement trajectory visible. Delta > 0.05 each iteration.

**Deliverable:** Joe Surface Report (grade, iterations, what shipped, what the machine couldn't resolve, process patches applied).

## Joe Surface Report Template

```
## [Faction] Card Set — Complete

**Final Grade:** [grade]
**Iterations:** [total] across [phase_count] phases
**Pre-gate:** CLEAN
**Delta log:** [summary]

### What shipped
- [files]

### What the machine couldn't resolve
- [open questions for Joe]

### Process improvements applied
- [patches to pipeline]
```

## Pitfalls

- **The documentation bottleneck is the root cause of all iteration loops.** If a sub-agent produces wrong output, the spec was incomplete. Fix it upstream.
- **Spec must EXCLUDE, not just INCLUDE.** "Professionals: epithets/role-names" → sub-agents use surnames. Must say "NO SURNAMES."
- **Format drift is the #1 friction point.** Enforce exact pipe table templates. Verify with grep before audit.
- **Workers must write FILES.** Explicitly require file writes in the sub-agent goal. "Write output to [path]" — not "return results."
- **Never skip spec validation.** One validator sub-agent caught 7 blocking errors that would have cascaded into 55 cards of rework.
- **Two-layer review is minimum viable.** pre_review_audit.py catches mechanical errors. Critic catches ludo, flavor, and identity. Neither alone is sufficient.
- **Fixer pass prevents full re-spawns.** Don't re-spawn all 3 workers for small count/coverage fixes.

## Integration

| Skill | Phase | Role |
|-------|-------|------|
| `faction-identity-gate` | Phase 0 | Identity verification |
| `tcg-faction-lore-phase` | Phase 0 | Lore lock (with Section 0 Canon Alignment) |
| `pathway-design` | Phase 2 | Crew profiles, turn maps, slot boundaries |
| `orchestrator` | Phases 3-7 | Spawn workers, track delta, escalate |
| `faction-set-review` | Phase 6 | Card set critic (Pass 2-3) |
| `density_calc.py` | Phase 1 | Draw probability verification |
| `pre_review_audit.py` | Phase 5 | Mechanical gate |

## Relationship to bruiser-card-design-pipeline

The `bruiser-card-design-pipeline` skill is the reference implementation. It contains the proven Phase 1-6 pattern for sub-agent card production. Pipeline specs in `workspace/pipelines/` are DERIVED from it. This master skill (`five-crests-card-pipeline`) ORCHESTRATES it — adding identity gate, spec validation, compound tracking, and the Joe Surface Report.

## Changelog

**2026-06-08** — Initial creation. Synthesized from Trigger v7 and Faceless v2 autonomous runs. Incorporates all kaizen from June 6-8.
